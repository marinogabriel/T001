package view;

import java.util.Calendar;
import java.util.List;
import model.AnimalDAO;
import model.Consulta;
import model.VeterinarioDAO;


public class ConsultaTableModel extends GenericTableModel {

    public ConsultaTableModel(List vDados) {
        super(vDados, new String[]{"Data", "Hora", "Histórico", "Exames", "Email"});
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return Calendar.class;
            case 1:
                return int.class;
            case 2:
                return String.class;
            case 3:
                return String.class;
            case 4:
                return String.class;
            case 5:
                return String.class; 
             
            default:
                throw new IndexOutOfBoundsException("columnIndex out of bounds");
        }
    }
    
   @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Consulta consulta = (Consulta) vDados.get(rowIndex);
        
        switch (columnIndex) {
            case 0:
                return consulta.getData();
            case 1:
                return consulta.getHora();
            case 2:
                return consulta.getHistorico();
            case 3:
                return consulta.getExames();
            case 4:
                return VeterinarioDAO.getInstance().retrieveById(consulta.getIdVeterinario());
            case 5:
                return AnimalDAO.getInstance().retrieveById(consulta.getIdAnimal());
            default:
                throw new IndexOutOfBoundsException("columnIndex out of bounds");
        }
    }
    
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Consulta consulta = (Consulta) vDados.get(rowIndex);
        
        switch (columnIndex) {
            case 0:
                consulta.setData((Calendar)aValue);
            case 1:
                consulta.setHora((int)aValue);
            case 2:
                consulta.setHistorico((String)aValue);
            case 3:
                consulta.setExames((String)aValue);
            default:
                throw new IndexOutOfBoundsException("columnIndex out of bounds");
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }   

}