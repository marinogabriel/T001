package view;


public class ConsultaTableModel {
    
}
