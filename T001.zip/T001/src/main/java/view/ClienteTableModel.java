package view;

public class ClienteTableModel {
    
}
