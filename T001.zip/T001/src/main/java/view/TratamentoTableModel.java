package view;

import java.util.Calendar;
import java.util.List;
import model.Tratamento;


public class TratamentoTableModel extends GenericTableModel {

    public TratamentoTableModel(List vDados) {
        super(vDados, new String[]{"Nome", "Endereço", "CEP", "Telefone", "Email"});
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return String.class;
            case 1:
                return String.class;
            case 2:
                return String.class;
            case 3:
                return String.class;
            case 4:
                return String.class;    
             
            default:
                throw new IndexOutOfBoundsException("columnIndex out of bounds");
        }
    }
    
   @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Tratamento tratamento = (Tratamento) vDados.get(rowIndex);
        
        switch (columnIndex) {
            case 0:
                return tratamento.getNome();
            case 1:
                return tratamento.getDataIni();
            case 2:
                return tratamento.getDataFim();
            case 3:
                return tratamento.getIdAnimal();
            case 4:
                return tratamento.isFinalizado();
            default:
                throw new IndexOutOfBoundsException("columnIndex out of bounds");
        }
    }
    
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Tratamento tratamento = (Tratamento) vDados.get(rowIndex);
        
        switch (columnIndex) {
            case 0:
               tratamento.setNome((String)aValue);
            case 1:
                tratamento.setDataIni((Calendar)aValue);
            case 2:
               tratamento.setDataFim((Calendar)aValue);
            case 3:
               tratamento.setIdAnimal((int)aValue);
            case 4:
               tratamento.setFinalizado((boolean)aValue);   
            default:
                throw new IndexOutOfBoundsException("columnIndex out of bounds");
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }   

}