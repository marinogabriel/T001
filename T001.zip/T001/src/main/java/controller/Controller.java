package controller;

import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.JTextField;
import model.Animal;
import model.AnimalDAO;
import model.Cliente;
import model.ClienteDAO;
import model.Especie;
import model.EspecieDAO;
import model.Veterinario;
import model.VeterinarioDAO;
import view.AnimalTableModel;
import view.ClienteTableModel;
import view.EspecieTableModel;
import view.GenericTableModel;
import view.VeterinarioTableModel;


public class Controller {
    
    private static Cliente clienteSelecionado = null;
    private static Animal animalSelecionado = null;
    private static Especie especieSelecionada = null;
    private static Veterinario veterinarioSelecionado = null;
    private static JTextField clienteSelecionadoTextField = null;
    private static JTextField animalSelecionadoTextField = null;
    private static JTextField especieSelecionadaTextField = null;
    
    public static void setTextFields(JTextField cliente, JTextField animal, JTextField especie) {
        clienteSelecionadoTextField = cliente;
        animalSelecionadoTextField = animal;
        especieSelecionadaTextField = especie;
    }
            
    
    public static void setTableModel(JTable table, GenericTableModel tableModel) {
        table.setModel(tableModel);
    }
    
    public static Cliente getClienteSelecionado() {
        return clienteSelecionado;
    }
    
    public static Animal getAnimalSelecionado() {
        return animalSelecionado;
    }
    
    public static Especie getEspecieSelecionada() {
        return especieSelecionada;
    }
    
    public static Veterinario getVeterinarioSelecionado() {
        return veterinarioSelecionado;
    }
    
    public static void setSelected(Object selected) {
        if(selected instanceof Cliente) {
            clienteSelecionado = (Cliente) selected;
            clienteSelecionadoTextField.setText(clienteSelecionado.getNome());
            animalSelecionadoTextField.setText("");
        } else if(selected instanceof Animal) {
            animalSelecionado = (Animal) selected;
            animalSelecionadoTextField.setText(animalSelecionado.getNome());
        }
        else if(selected instanceof Especie) {
            especieSelecionada = (Especie) selected;
            especieSelecionadaTextField.setText(especieSelecionada.getNome());
        }
        else if(selected instanceof Veterinario) {
            veterinarioSelecionado = (Veterinario) selected;
            //animalSelecionadoTextField.setText(animalSelecionado.getNome());
        }
    }
    
    public static void clearSelected(Object selected) {
         if(selected instanceof Cliente) {
            clienteSelecionadoTextField.setText("");
            animalSelecionadoTextField.setText("");
        } else if(selected instanceof Animal) {
            animalSelecionadoTextField.setText("");
        }
        else if(selected instanceof Especie) {
            especieSelecionada = (Especie) selected;
        }
        else if(selected instanceof Veterinario) {
            veterinarioSelecionado = (Veterinario) selected;
        }
    }
    
    public static boolean jRadioButtonClientes(JTable table) {
        setTableModel(table, new ClienteTableModel(ClienteDAO.getInstance().retrieveAll()));
        return true;
    }
    
    public static boolean jRadioButtonVeterinarios(JTable table) {
        setTableModel(table, new VeterinarioTableModel(VeterinarioDAO.getInstance().retrieveAll()));
        return true;
    }
    
    public static boolean jRadioButtonEspecies(JTable table) {
        setTableModel(table, new EspecieTableModel(EspecieDAO.getInstance().retrieveAll()));
        return true;
    }
    
    public static boolean jRadioButtonAnimais(JTable table) {
        if(getClienteSelecionado() != null) {
            setTableModel(table, new AnimalTableModel(AnimalDAO.getInstance().retrieveByIdCliente(getClienteSelecionado().getId())));
            return true;
        }else {
            setTableModel(table, new AnimalTableModel(new ArrayList()));
            return false;
        }
    }
     
}
