package model;

public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClienteDAO.getInstance();
    }
    
}
